/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pooproject;

import java.awt.Frame;

/**
 *Classe principal do projeto, que inicia.
 * 
 * @author Thiago Sandes & André Biriba
 * @version 1.0
 * @since entrega de projeto na materia de ED1 18/04/2017
 */
public class Main{

    /**Metodo principal da classe Main*/
    public static void main(String args[]){
        MainFrame frame = new MainFrame();
    }
}
