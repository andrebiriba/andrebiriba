/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pooproject;

/**
 *Implementada pela classe Agenda.
 * 
 * @author Thiago Sandes & André Biriba
 * @version 1.0
 * @since entrega de projeto da materia de ED1 18/04/2017
 */
public interface Interface {
    
    /**Metodo abstrato implementado na classe Agenda
     * @param parametro int - tempo em nanosegundos
    */
    public void delay(int parametro);
    
}
